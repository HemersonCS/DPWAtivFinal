export const inputCheck = document.querySelector('#modo-noturno')
export const elemento = document.querySelector('body')


