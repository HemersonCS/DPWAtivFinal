import cadastro from "../models/Cadastro.js";

class CadastroController {

  static async listarCadastro (req, res) {
    try {
      const listaCadastro = await cadastro.find({});
      res.status(200).json(listaCadastro);
    } catch (erro) {
      res.status(500).json({ message: `${erro.message} - falha na requisição` });
    }
  };

  static async listarCadastroPorId (req, res) {
    try {
      const id = req.params.id;
      const cadastroEncontrado = await cadastro.findById(id);
      res.status(200).json(cadastroEncontrado);
    } catch (erro) {
      res.status(500).json({ message: `${erro.message} - falha na requisição do cadastro` });
    }
  };

  static async cadastrarCadastro (req, res) {
    try {
      const novoCadastro = await cadastro.create(req.body);
      res.status(201).json({ message: "criado com sucesso", cadastro: novoCadastro });
    } catch (erro) {
      res.status(500).json({ message: `${erro.message} - falha ao cadastrar novo cadastro` });
    }
  }

  static async atualizarCadastro (req, res) {
    try {
      const id = req.params.id;
      await cadastro.findByIdAndUpdate(id, req.body);
      res.status(200).json({ message: "Cadastro atualizado" });
    } catch (erro) {
      res.status(500).json({ message: `${erro.message} - falha na atualização` });
    }
  };

  static async excluirCadastro (req, res) {
    try {
      const id = req.params.id;
      await cadastro.findByIdAndDelete(id);
      res.status(200).json({ message: "Cadastro excluído com sucesso" });
    } catch (erro) {
      res.status(500).json({ message: `${erro.message} - falha na exclusão` });
    }
  };
};

export default CadastroControllerController;